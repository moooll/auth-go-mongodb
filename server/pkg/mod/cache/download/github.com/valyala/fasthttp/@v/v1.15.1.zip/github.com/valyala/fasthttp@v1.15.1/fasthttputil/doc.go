// Package fasthttputil provides utility functions for fasthttp.
package fasthttputil
